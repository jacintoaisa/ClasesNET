﻿// See https://aka.ms/new-console-template for more information
using ObdulioYTienda;

IValidador MiValidadorPositivo = new ValidadorPositivo();
IFabricaVendibles MiFabrica = new FabricaJacinto();
MiFabrica.Validador = MiValidadorPositivo;

IColeccionVendibles MovDiario = new MovimientosDiarios();
Console.WriteLine("Que Desea Hacer: X para salir");
var entrada = Console.ReadLine();
while (entrada.ToUpper() != "X")
{
    if (entrada == "1")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Lentorro);
        if (MiValidadorPositivo.isValid(MiOrdenador))
            MovDiario.Add(MiOrdenador);
        Console.WriteLine("Creado Lentorro...");
    }
    if (entrada == "2")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Normal);
        if (MiValidadorPositivo.isValid(MiOrdenador))
            MovDiario.Add(MiOrdenador);
        Console.WriteLine("Creado Normal...");
    }
    if (entrada == "3")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Gamer);
        if (MiValidadorPositivo.isValid(MiOrdenador))
            MovDiario.Add(MiOrdenador);
        Console.WriteLine("Creado Gamer...");
    }
    Console.WriteLine("Que Desea Hacer: X para salir");
    entrada = Console.ReadLine();
}

Console.WriteLine($"El total ingresado es {MovDiario.TotalImporteFacturado()}");


