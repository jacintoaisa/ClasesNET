﻿// See https://aka.ms/new-console-template for more information
using ObdulioYTienda;

IValidador MiValidadorPositivo = new ValidadorPositivo();
IFabricaVendibles MiFabrica = new FabricaJacinto();
MiFabrica.Validador = MiValidadorPositivo;

IColeccionVendibles MovDiario = new MovimientosDiarios();

var entrada = "";
while (entrada.ToUpper() != "X")
{
    MuestraOpciones();
    entrada = Console.ReadLine();

    if (entrada == "1")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Lentorro);
        Pon(MiOrdenador, "Lentorro");
    }
    if (entrada == "2")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Normal);
        Pon(MiOrdenador, "Normal");
    }
    if (entrada == "3")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Gamer);
        Pon(MiOrdenador, "Gamer");
    }
    if (entrada == "4")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Lentorro, damePrecio(), dameGarantia());
        Pon(MiOrdenador, "Lentorro Personalizado");
    }
    if (entrada == "5")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Normal, damePrecio(), dameGarantia());
        Pon(MiOrdenador, "Lentorro Personalizado");
    }
    if (entrada == "6")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Gamer, damePrecio(), dameGarantia());
        Pon(MiOrdenador, "Lentorro Personalizado");
    }
    Console.WriteLine("Que Desea Hacer: X para salir");
}

Console.WriteLine($"El total ingresado es {MovDiario.TotalImporteFacturado()}");

void Pon(IVendible MiOrdenador, string texto)
{
    if (MiOrdenador != null)
    {
        MovDiario.Add(MiOrdenador);
        Console.WriteLine($"Creado {texto} ..");
    }
    else
    {
        Console.WriteLine($"Error en la creación del ordenador {texto}");
    }
}

int damePrecio()
{
    Console.WriteLine("Mete precio");
    return Int32.Parse(Console.ReadLine());
}
int dameGarantia()
{
    Console.WriteLine("Mete garantia");
    return Int32.Parse(Console.ReadLine());
}
 void MuestraOpciones()
{
    Console.WriteLine("Que Ordenador desea:");
    Console.WriteLine("1.- Lentorro Estandar");
    Console.WriteLine("2.- Normal Estandar");
    Console.WriteLine("3.- Gamer Estandar");
    Console.WriteLine("4.- Lentorro valores personalizados");
    Console.WriteLine("5.- Normal valores personalizados");
    Console.WriteLine("6.- Gamer valores personalizados");
    Console.WriteLine("X.- Salir");
}