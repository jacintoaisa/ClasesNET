﻿// See https://aka.ms/new-console-template for more information
using ObdulioYTienda;

IValidador MiValidadorPositivo = new ValidadorPositivo();
IFabricaVendibles MiFabrica = new FabricaJacinto();
MiFabrica.Validador = MiValidadorPositivo;

IColeccionVendibles MovDiario = new MovimientosDiarios();
Menu MiMenu = new Menu();

var entrada = "";
while (entrada.ToUpper() != "X")
{
    MiMenu.MuestraOpciones();
    entrada = Console.ReadLine();
    if (entrada == "1")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Lentorro);
        if (MiOrdenador != null)
        {
            MovDiario.Add(MiOrdenador);
            Console.WriteLine("Creado Lentorro...");
        }
        else
        {
            Console.WriteLine("Error en la creación");
        }
    }
    if (entrada == "2")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Normal);
        if (MiOrdenador != null)
        {
            MovDiario.Add(MiOrdenador);
            Console.WriteLine("Creado Normal...");
        }
        else
        {
            Console.WriteLine("Error en la creación");
        }
    }
    if (entrada == "3")
    {
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Gamer);
        if (MiOrdenador != null)
        {
            MovDiario.Add(MiOrdenador);
            Console.WriteLine("Creado Gamer...");
        }
        else
        {
            Console.WriteLine("Error en la creación");
        }

    }
    if (entrada == "4")
    {
        Console.WriteLine("Mete precio");
        int precio = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Mete garantia");
        int garantia = Int32.Parse(Console.ReadLine());
        IVendible MiOrdenador = MiFabrica.DameVendible(TipoOrdenador.Lentorro, precio, garantia);
        if (MiOrdenador != null)
        { 
            MovDiario.Add(MiOrdenador);
            Console.WriteLine("Creado Lentorro personalizado");
        }
        else
        { 
            Console.WriteLine("Error en la creación"); 
        }

    }
    Console.WriteLine("Que Desea Hacer: X para salir");
}

Console.WriteLine($"El total ingresado es {MovDiario.TotalImporteFacturado()}");


