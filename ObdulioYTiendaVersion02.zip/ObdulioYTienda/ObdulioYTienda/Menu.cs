﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObdulioYTienda
{
    public class Menu
    {
        string opcion = "";
        public void MuestraOpciones()
        {
            Console.WriteLine("Que Ordenador desea:");
            Console.WriteLine("1.- Lentorro Estandar");
            Console.WriteLine("2.- Normal Estandar");
            Console.WriteLine("3.- Gamer Estandar");
            Console.WriteLine("4.- Lentorro valores personalizados");
            Console.WriteLine();
            Console.WriteLine("X.- Salir");
        }
    }
}
