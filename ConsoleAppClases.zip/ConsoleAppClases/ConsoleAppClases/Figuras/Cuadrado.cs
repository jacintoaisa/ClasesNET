﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleAppClases.Figuras
{
    public class Cuadrado : IMedible
    {
        public int Lado { get; set; }

        public double damePerimetro()
        {
            return Lado * 4;
        }

        public double dameSuperficie()
        {
            return Lado * Lado;
        }
    }
}