﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleAppClases.Figuras
{
    public class Factoria01 : IFactoriaMedibles
    {
        public IMedible DameFigura(TipoFigura tipo, int valor)
        {
            switch (tipo)
            {
                case TipoFigura.Circulo: return new Circulo() { Radio = valor };
                default: return new Cuadrado() { Lado = valor };
            }

        }
    }
}