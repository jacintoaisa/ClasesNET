﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleAppClases.Figuras
{
    public class Circulo : IMedible
    {
        public int Radio { get; set; }


        public double damePerimetro()
        {
            return 2 * Math.PI * Radio;
        }

        public double dameSuperficie()
        {
            return Math.PI * Math.Pow(Radio, 2);
        }
    }
}