﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppClases.Modelo
{
    public class Coche
    {
        public Coche(string matricula, bool cabe = false)
        {
            Matricula = matricula;
            Cabe = cabe;
        }
        public Coche() { }

        //Lectura y escritura
        public string Matricula { get; set; }
        //Solo recuperar
        public bool Cabe { get; set; } = false;

        public override string ToString()
        {
            return "Matricula: " + this.Matricula + ", " + this.Cabe;
        }

        public override bool Equals(object? obj)
        {
            return obj is Coche coche && Matricula == coche.Matricula;
        }

        public int CompareTo(Coche other)
        {
            return this.Matricula.CompareTo(other.Matricula);
        }

    }
}
