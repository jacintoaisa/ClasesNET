﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public class Fabrica01 : IFabricaIVendibles
    {
        public IValidable Validador { get; set; }

        public Fabrica01(IValidable Validador)
        {
            this.Validador = Validador;
        }
        public IVendible dameInstancia(EnumTipoVendible tipo)
        {
            IVendible vendible = null;
            switch(tipo)
            {
                case EnumTipoVendible.JarronMing: 
                    vendible = new JarronMing();break;
                default: vendible = new JarronPorcelana();break;
            }
            if (Validador.isValid(vendible))
            {
                return vendible;
            }
            else
            {
                return null;
            }
        }
    }
}