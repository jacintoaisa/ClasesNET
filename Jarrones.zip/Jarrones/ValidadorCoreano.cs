﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public class ValidadorCoreano : IValidable
    {
        public bool isValid(IVendible Elemento)
        {
            return (Elemento.PrecioFabricacion > 1);
        }
    }
}