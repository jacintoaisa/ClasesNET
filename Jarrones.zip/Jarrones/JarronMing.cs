﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;

namespace Jarrones
{
    public class JarronMing : IVendible
    {
        public double PVP { get; set; } = 10000;
        public double PrecioFabricacion { get; set; } = 7000; 

        public double dameBeneficio()
        {
            return this.PVP - this.PrecioFabricacion;
        }
    }
}