﻿// See https://aka.ms/new-console-template for more information
using Jarrones;

IValidable validador = new ValidadorCoreano();
IFabricaIVendibles MiFabrica = new Fabrica01(validador);
ColeccionAmpliada MiGestor = new ColeccionAmpliada();
MiGestor.Add(MiFabrica.dameInstancia(EnumTipoVendible.JarronMing));
MiGestor.Add(MiFabrica.dameInstancia(EnumTipoVendible.JarronPorcelana));
MiGestor.Add(MiFabrica.dameInstancia(EnumTipoVendible.JarronMing));

Console.WriteLine($"Coste Total {MiGestor.dameCoste()}");
Console.WriteLine($"Beneficio Total {MiGestor.dameBeneficio()}");
Console.WriteLine($"Venta Total {MiGestor.dameVenta()}");
Console.WriteLine($"Tasa Total {MiGestor.dameTasa()}");

