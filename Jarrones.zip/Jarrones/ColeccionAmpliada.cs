﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public class ColeccionAmpliada : Coleccion01
    {
        public double dameTasa()
        {
            double Tasa = 0;
            foreach (var item in base.elementosVenta)
            {
                if (item is ITasable)
                {
                    Tasa += (item as ITasable).Tasa;
                }

            }
            return Tasa;
        }
    }
}