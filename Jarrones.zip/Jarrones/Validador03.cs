﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;

namespace Jarrones
{
    public class Validador03 : Validador02
    {
        public bool isValid(IVendible Elemento)
        {
           return base.isValid(Elemento) && Elemento.PVP > 100;
        }
    }
}