﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public class Coleccion01 : IColeccionVendible
    {
        public List<IVendible> elementosVenta { get; set; } = new List<IVendible>();
        double totalBeneficio = 0;
        double totalCoste = 0;
        double totalVentas = 0;
        public bool Add(IVendible elemento)
        {
            elementosVenta.Add(elemento);
            totalCoste += elemento.PrecioFabricacion;
            totalBeneficio += elemento.dameBeneficio();
            totalVentas += elemento.PVP;
            return true;
        }

        public double dameBeneficio()
        {
            return this.totalBeneficio;
        }

        public double dameCoste()
        {
            return this.totalCoste;
        }

        public double dameVenta()
        {
            return this.totalVentas;
        }
    }
}