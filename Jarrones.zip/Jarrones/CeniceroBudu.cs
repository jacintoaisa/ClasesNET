﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public class CeniceroBudu : IVendible, ITasable
    {
        public double PVP { get; set; } = 60;
        public double PrecioFabricacion { get; set; } = 10;
        public double Tasa { get; set; } = 16;

        public double dameBeneficio()
        {
            return PVP - PrecioFabricacion;
        }

    }
}