﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public interface IColeccionVendible
    {
        double dameCoste();
        double dameVenta();
        double dameBeneficio();
        bool Add(IVendible elemento);
    }
}