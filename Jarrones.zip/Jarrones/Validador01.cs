﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jarrones
{
    public class Validador01 : IValidable
    {
        public bool isValid(IVendible Elemento)
        {
            return (Elemento.PrecioFabricacion > 0 && Elemento.PVP > 0);
        }
    }
}